#pragma once

void init_Debug();