#pragma once

void init_GUI();