#pragma once

extern const uint8_t gImage_ACFLY[];
extern const uint8_t gImage_BG1[];
extern const uint8_t gImage_Circle1[];