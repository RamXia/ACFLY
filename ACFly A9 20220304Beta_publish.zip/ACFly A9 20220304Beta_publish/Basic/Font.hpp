#pragma once

extern const uint8_t Font_16x8[][16];
extern const uint8_t Font_24x12[][48];
extern const uint8_t Font_32x16[][64];